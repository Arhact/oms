    <div class="woo_left_cont">
             <span class="article_filtr">Фильтр</span>
                     <?php dynamic_sidebar( 'right-sidebar' ); ?> 
        </div>
        <div class="woo_right_cont">
        <?php
                woocommerce_content(); 
            ?>
        </div>   

 