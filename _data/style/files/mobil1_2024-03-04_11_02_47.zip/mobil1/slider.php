    <div class="container-fluid slider_bg slider_bg_small">
     <div class="home_banner">
          <!-- Wrapper for slides -->
              <div class="slider_text_cont">
                  <div class="slide_text">
                    <div class="logo">
                        <a href="https://kdmobil.ru"> 
                            <img alt="Автосервис Mobil 1 Центр Третьяковский" src="<?php bloginfo("template_directory");?>/img/logo.png">
                       </a>
                    </div>
                  </div>
                </div>
              </div> 
            <div class="slider_bottom">
                <div class="container">
                    <a class="banner" href="tel:+74012913444">
                        <i class="icon-phone" aria-hidden="true"></i>
                        <span>Позвонить</span> 
                    </a> 
                    <a class="banner" href="https://kdmobil.ru/kontakty/">
                        <i class="icon-location" aria-hidden="true"></i>
                        <span>Как добраться</span>
                    </a>
                    <a class="banner" href="#openModal"  onclick="search_add();">
                        <i class="icon-question-circle-o" aria-hidden="true"></i>
                        <span>Задать вопрос</span>
                    </a>
                </div>
            </div>  


</div>